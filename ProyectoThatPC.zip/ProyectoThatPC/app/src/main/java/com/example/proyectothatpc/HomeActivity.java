package com.example.proyectothatpc;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    //recyclerview no funciona

    ArrayList<Moviles> listamoviles;

    RecyclerView recyclermoviles;

    public static final String user="names";

    TextView txtUser;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        txtUser = (TextView) findViewById(R.id.textser);
        String user = getIntent().getStringExtra("names");
        txtUser.setText("Bienvenido " + user + "!");


        listamoviles = new ArrayList<>();
        recyclermoviles = (RecyclerView) findViewById(R.id.recyclerMovil);
        recyclermoviles.setLayoutManager(new LinearLayoutManager(this));

        llenarmoviles();

        AdaptadorMoviles adapter = new AdaptadorMoviles(listamoviles);
        recyclermoviles.setAdapter(adapter);
    }

    private void llenarmoviles(){
        listamoviles.add(new Moviles("Samsung", "s10", R.drawable.ico_samsung));
        listamoviles.add(new Moviles("Apple", "iphoneXR", R.drawable.ico_apple));
        listamoviles.add(new Moviles("nokia", "7.1", R.drawable.ico_nokia));
        listamoviles.add(new Moviles("huawei", "Mi note 10", R.drawable.xiaomi));
        listamoviles.add(new Moviles("lg", "g7", R.drawable.ico_lg));
    }
}
