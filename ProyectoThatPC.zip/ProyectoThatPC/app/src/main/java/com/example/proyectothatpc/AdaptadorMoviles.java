package com.example.proyectothatpc;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class AdaptadorMoviles extends RecyclerView.Adapter<AdaptadorMoviles.ViewHolderMoviles> {

    ArrayList<Moviles> listamoviles;

    public AdaptadorMoviles(ArrayList<Moviles> listamoviles) {
        this.listamoviles = listamoviles;
    }

    public class ViewHolderMoviles extends RecyclerView.ViewHolder {

        TextView etinombre, etiinfo;
        ImageView foto;

        public ViewHolderMoviles(@NonNull View itemView) {
            super(itemView);
            etinombre = (TextView) itemView.findViewById(R.id.idMarca);
            etiinfo = (TextView) itemView.findViewById(R.id.idInfo);
            foto = (ImageView) itemView.findViewById(R.id.logo);

        }
    }
    @NonNull
    @Override
    public ViewHolderMoviles onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_recycler,null, false);
        return new ViewHolderMoviles(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderMoviles holder, int position) {

        holder.etinombre.setText(listamoviles.get(position).getNombre());
        holder.etiinfo.setText(listamoviles.get(position).getInfo());
        holder.foto.setImageResource(listamoviles.get(position).getFoto());

    }

    @Override
    public int getItemCount() {
        return listamoviles.size();
    }


}
