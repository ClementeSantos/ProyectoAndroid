package com.example.proyectothatpc;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText Txtemail;
    private EditText Txtpassword;
    private Button btnLogin;



    //FirebaseAuth
    private FirebaseAuth fbauth;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fbauth = FirebaseAuth.getInstance();

        Txtemail = (EditText) findViewById(R.id.loguser);
        Txtpassword = (EditText) findViewById (R.id.logpassword);
        btnLogin = (Button) findViewById(R.id.Login);

        btnLogin.setOnClickListener(this);

        Button btn = (Button) findViewById(R.id.goRegistro);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (v.getContext(), RegisterActivity.class);
                startActivityForResult(intent, 0);
            }
        });
    }


    private void logearusuario(){
        final String email = Txtemail.getText().toString().trim();
        final String password = Txtpassword.getText().toString().trim();
        if(TextUtils.isEmpty(email)) {
            Toast.makeText(this, "Se debe ingresar email", Toast.LENGTH_LONG).show();
            return;
        }
        if(TextUtils.isEmpty(password)){
            Toast.makeText(this, "Se debe ingresar contraseña", Toast.LENGTH_LONG).show();
            return;
        }



        fbauth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            int pos = email.indexOf("@");
                            String user = email.substring(0, pos);
                            Toast.makeText(MainActivity.this, "Bienvenido :)!",Toast.LENGTH_LONG).show();
                            Intent intencion = new Intent(getApplication(), HomeActivity.class);
                            intencion.putExtra(HomeActivity.user, user);
                            startActivity(intencion);
                        }else{
                            if(task.getException() instanceof FirebaseAuthUserCollisionException){
                                Toast.makeText(MainActivity.this, "Usa bien tus credenciales", Toast.LENGTH_LONG).show();
                            }else {
                                Toast.makeText(MainActivity.this, "Error en el logeo", Toast.LENGTH_SHORT).show();
                            }

                        }
                    }
                });

    }

    @Override
    public void onClick(View view){
        logearusuario();
    }
}
